package com.example.demo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class CalculatorController {

        @GetMapping("/calculator")
    public ResponseEntity<String> calculator(@RequestParam(value = "firstNumber",  defaultValue = "") String firstNumber,
                                             @RequestParam(value = "secondNumber",  defaultValue = "") String secondNumber,
                                             @RequestParam(value = "operator",  defaultValue = "") String operator) {

        if (firstNumber.isEmpty() || secondNumber.isEmpty()) {
            return ResponseEntity.badRequest().body("Cannot empty");
        } else if (!isDouble(firstNumber) || !isDouble(secondNumber) ) {
            return ResponseEntity.badRequest().body("Number is numeric!!");
        }
       double firstNumberDouble = Double.parseDouble(firstNumber);
        double secondNumberDouble = Double.parseDouble(secondNumber);
        double result;
        switch (operator) {
            case "+" -> result = firstNumberDouble + secondNumberDouble;
            case "-" -> result = firstNumberDouble - secondNumberDouble;
            case "*" -> result = firstNumberDouble * secondNumberDouble;
            case "/" -> {
                if (secondNumberDouble == 0) {
                    return ResponseEntity.badRequest().body("Cannot divide by zero!");
                }
                result = firstNumberDouble / secondNumberDouble;
            }
            default -> {
                return ResponseEntity.badRequest().body("Invalid operator");
            }

        }
        return ResponseEntity.ok("result = " + result);
    }


    private boolean isDouble(String str){
    try {
        Double.parseDouble(str);
        return true;
    }catch(NumberFormatException e){
        return false;
    }
    }
}
